import random

def calculate_damage(attacker, defender, move):
    """Calcula el daño de un movimiento."""
    # Lógica para calcular el daño basado en las estadísticas del Pokémon, el movimiento y otros factores
    # ...
    return damage

def choose_random_move(pokemon):
    """Selecciona un movimiento aleatorio del Pokémon."""
    return random.choice(pokemon.moves)

def clear_console():
    """Limpia la consola (puede variar según el sistema operativo)."""
    # Implementación para limpiar la consola en diferentes sistemas operativos
    # ...

def get_user_input(prompt, valid_options=None):
    """Obtiene una entrada del usuario y la valida."""
    while True:
        user_input = input(prompt)
        if valid_options and user_input not in valid_options:
            print("Opción inválida. Por favor, elige una de las siguientes opciones:")
            for option in valid_options:
                print(option)
        else:
            return user_input