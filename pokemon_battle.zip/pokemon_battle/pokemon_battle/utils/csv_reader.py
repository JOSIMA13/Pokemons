import pandas as pd

class CSVReader:
    def read_csv(self, filename):
        data = pd.read_csv(filename)
        pokemons = []
        # Iterar sobre las filas y crear objetos Pokémon
        for index, row in data.iterrows():
            moves = [Move(move_name, move_type, move_power, move_accuracy, move_category, move_effect) for move_name, move_type, move_power, move_accuracy, move_category, move_effect in zip(row['move1'], row['move2'], ...)]  # Assuming multiple moves per Pokémon
            pokemon = Pokemon(row['name'], row['type'], row['hp'], row['attack'], row['defense'], row['speed'], moves)
            pokemons.append(pokemon)
        return pokemons