class Battle:
    def __init__(self, pokemon1, pokemon2):
        self.pokemon1 = pokemon1
        self.pokemon2 = pokemon2

    def start(self):
        # Bucle principal de la batalla
        while self.pokemon1.hp > 0 and self.pokemon2.hp > 0:
            # Lógica de turnos, selección de movimientos, etc.