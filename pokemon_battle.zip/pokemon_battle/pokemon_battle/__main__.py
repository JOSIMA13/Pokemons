from models.pokemon import Pokemon
from battles.battle import Battle
from utils.csv_reader import CSVReader

# Ejemplo de uso:
if __name__ == "__main__":
    reader = CSVReader()
    pokemons = reader.read_csv('data/pokemon.csv')

    # Crear una batalla
    battle = Battle(pokemons[0], pokemons[1])
    battle.start()