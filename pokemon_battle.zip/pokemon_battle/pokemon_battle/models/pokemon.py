class Pokemon:
    def __init__(self, name, type, hp, attack, defense, speed, moves):
        self.name = name
        self.type = type
        self.hp = hp
        self.attack = attack
        self.defense = defense
        self.speed = speed
        self.moves = moves

    def attack(self, other_pokemon, move):
        # Lógica de ataque, cálculo de daño, etc.
        # Considerar tipo de movimiento, efectividad, estados alterados