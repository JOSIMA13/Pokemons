class Type:
    def __init__(self, name, strengths, weaknesses):
        self.name = name
        self.strengths = strengths
        self.weaknesses = weaknesses