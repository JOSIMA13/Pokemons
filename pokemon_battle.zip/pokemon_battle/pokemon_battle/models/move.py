class Move:
    def __init__(self, name, type, power, accuracy, category, effect):
        self.name = name
        self.type = type
        self.power = power
        self.accuracy = accuracy
        self.category = category
        self.effect = effect