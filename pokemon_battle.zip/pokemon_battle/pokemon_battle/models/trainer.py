from models.pokemon import Pokemon

class Trainer:
    def __init__(self, name):
        self.name = name
        self.team = []

    def add_pokemon(self, pokemon):
        """Agrega un Pokémon al equipo del entrenador."""
        if isinstance(pokemon, Pokemon):
            self.team.append(pokemon)
        else:
            raise TypeError("El elemento a agregar debe ser un objeto de tipo Pokemon")

    def choose_pokemon(self, index):
        """Selecciona un Pokémon del equipo por índice."""
        if 0 <= index < len(self.team):
            return self.team[index]
        else:
            raise IndexError("Índice de Pokémon inválido")

    def show_team(self):
        """Muestra la información de todos los Pokémon del equipo."""
        for i, pokemon in enumerate(self.team):
            print(f"{i+1}. {pokemon.name} ({pokemon.type})")