class StatusCondition:
    def __init__(self, name, duration, effects):
        self.name = name
        self.duration = duration
        self.effects = effects