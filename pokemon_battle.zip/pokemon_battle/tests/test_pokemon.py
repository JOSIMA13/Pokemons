import unittest
from models.pokemon import Pokemon
from models.move import Move

class TestPokemon(unittest.TestCase):
    def setUp(self):
        # Crear un Pokémon de prueba
        self.pikachu = Pokemon("Pikachu", "Electric", 100, 50, 50, 100, [
            Move("Thunderbolt", "Electric", 90, 100, "Special", None)
        ])

    def test_initialization(self):
        # Verificar que los atributos se inicialicen correctamente
        self.assertEqual(self.pikachu.name, "Pikachu")
        self.assertEqual(self.pikachu.type, "Electric")
        self.assertEqual(self.pikachu.hp, 100)
        # ... y así sucesivamente para todos los atributos

    def test_attack(self):
        # Crear otro Pokémon para recibir el ataque
        charmander = Pokemon("Charmander", "Fire", 100, 50, 50, 100, [])
        # Simular un ataque y verificar si se resta HP al Pokémon atacado
        initial_hp = charmander.hp
        self.pikachu.attack(charmander, self.pikachu.moves[0])
        self.assertLess(charmander.hp, initial_hp)

    # Agrega más pruebas para cubrir diferentes escenarios:
    # - Verificar que el tipo de movimiento afecte el daño
    # - Verificar que los estados alterados afecten las estadísticas
    # - Verificar que el nivel de precisión del movimiento influya en si acierta o falla